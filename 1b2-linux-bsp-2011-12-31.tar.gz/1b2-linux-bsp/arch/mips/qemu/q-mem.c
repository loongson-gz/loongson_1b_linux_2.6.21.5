#include <linux/init.h>

void __init prom_free_prom_memory(void)
{
}
