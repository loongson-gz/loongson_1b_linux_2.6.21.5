/*
 * fixup-ls232-board.c
 *
 * Copyright (C) 2004 ICT CAS
 * Author: Li xiaoyu, ICT CAS
 *   lixy@ict.ac.cn
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the  License, or (at your
 *  option) any later version.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
//#include <linux/config.h>
#include <linux/autoconf.h>
#include <linux/init.h>
#include <linux/pci.h>
#if 0
#include <asm/ict/p6032.h>
#include <asm/ict/p6032int.h>
#include <asm/ict/bonito.h>
#include <asm/ict/i82371eb.h>
#endif

#if 0
static char irq_pci_tab[][5] __initdata = {
        /*      INTA    INTB    INTC    INTD */
  [13]=      {0,     P6032INT_IRQA,      0,      0,      0 },    /*  7: */
  [14]=      {0,     P6032INT_IRQB,      0,      0,      0 },    /*  8: */
  [15]=      {0,     P6032INT_IRQC,      0,      0,      0 },    /*  9: */
  [18]=      {0,     P6032INT_IRQD,      0,      0,      0 },    /*  9: */
  [16]=      {0,     P6032INT_ETH,      0,      0,      0 },    /*  9: */
  //[17]=      {0,     P6032INT_ISAIDE0,      0,      0,      0 },    /*   */
  //[17]=      {0,     39,      0,      0,      0 },    /*   */
};
#endif

#define LS232_PCI_INTA    16
#define LS232_PCI_INTB    17
#define LS232_PCI_INTC    18
#define LS232_PCI_INTD    19

int __init pcibios_map_irq(struct pci_dev *dev, u8 slot, u8 pin)
{
	printk("pcibios_map_irq devfn : %d , slot : %d , pin : %d\n",PCI_SLOT(dev->devfn),slot,pin);
//	if (PCI_SLOT(dev->devfn) == 14) {
	if (PCI_SLOT(dev->devfn) == 10) {
		dev->irq = LS232_PCI_INTA;
		(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
	}
	 else if (PCI_SLOT(dev->devfn) == 11) {
//	else if (PCI_SLOT(dev->devfn) == 11) {
		dev->irq = LS232_PCI_INTB;
//zgj		dev->irq = LS232_PCI_INTC;
		(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
	}
	 else if (PCI_SLOT(dev->devfn) == 13) {
//	else if (PCI_SLOT(dev->devfn) == 11) {
		dev->irq = LS232_PCI_INTC;
//zgj		dev->irq = LS232_PCI_INTC;
		(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
	}
/*
	else if (PCI_SLOT(dev->devfn) == 13) {
		dev->irq = 19;
//zgj		dev->irq = LS232_PCI_INTC;
		(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
	}
*/
	else {
		dev->irq = LS232_PCI_INTB;
//zgj		dev->irq = LS232_PCI_INTD;
//		dev->irq = LS232_PCI_INTA + pin -1;
//qf		dev->irq = LS232_PCI_INTB;
		(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
		printk("ZZGJ IRQ : %d , PIN : %d \n",dev->irq,pin);
	}
	return dev->irq;
}

/* Do platform specific device initialization at pci_enable_device() time */
int pcibios_plat_dev_init(struct pci_dev *dev)
{
	return 0;
}
#if 0
static void __init godson2e_piix_func0_fixup(struct pci_dev *pdev)
{
		u8 v8;
		u16 v16;
		u32 v32;
		unsigned int v;
		char *fmt;
		struct {
			char *name;
			int offset;
			int  width;
		} *rp, regs[] = {
			{"VendorID",	0x00, 2},
			{"DeviceID",	0x02, 2},
			{"Command",	0x04, 2},
			{"Status",	0x06, 2},
			{"Class/RevID",	0x08, 4},
			{"CacheLineSize", 0x0c, 1},
			{"Latency",	0x0d, 1},
			{"HeaderType",	0x0e, 1},
			{"PrimaryBus",	0x18, 1},
			{"SecondaryBus", 0x19, 1},
			{"SubordinateBus", 0x1a, 1},
			{"SecLatency",	0x1b, 1},
			{"IOBase",	0x1c, 1},
			{"IOLimit",	0x1d, 1},
			{"SecStatus",	0x1e, 2},
			{"MemBase",	0x20, 2},
			{"MemLimit",	0x22, 2},
			{"PMemBase",	0x24, 2},
			{"PMemLimitUpper",0x28, 4},
			{"PMemLimitUpper",0x2c, 4},
			{"IOBaseUpper",	0x30, 2},
			{"IOLimitUpper",	0x32, 2},
			{"ECP",		0x34, 1},
			{"IntLine",	0x3c, 1},
			{"IntPin",	0x3d, 1},
			{"BridgeControl",0x3e, 2},
			{"ChipControl",	0x40, 2},
			{"ArbiterControl",0x42, 2},
			{"SecClock",	0x68, 2},
			{"ClkRun",	0x6f, 1},
			{"CapID",	0x80, 1},
			{"Next",	0x81, 1},
			{"PowerCap",	0x82, 2},
			{"PowerCSR",	0x84, 2},
			{"PMCSRBridge",	0x86, 1},
			{"CapID",	0x90, 1},
			{"Next",	0x91, 1},
			{"HCCSR",	0x92, 1},
			{"HotSwap",	0x94, 1},
			{"CapID",	0xa0, 1},
			{"Next",	0xa1, 1},
			{"VPD",		0xa2, 2},
			{"VPDData",	0xa4, 4},
			{"MiscCtl",	0xc1, 1},
			{"ArbiterCtl",	0xc3, 1},
			{"MiscCtl2",	0xc4, 1},
			{0,0,0}
		};
			
		for (rp = regs; rp->name; rp++) {
			switch (rp->width) {
			case 1:
				(void) pci_read_config_byte (pdev, rp->offset, &v8);
				v = v8;
				fmt = "%20s: %02x %02x\n";
				break;
			case 2:
				(void) pci_read_config_word (pdev, rp->offset, &v16);
				v = v16;
				fmt = "%20s: %02x %04x\n";
				break;
			case 4:
				(void) pci_read_config_dword (pdev, rp->offset, &v32);
				v = v32;
				fmt = "%20s: %02x %08x\n";
				break;
			}
			printk (fmt, rp->name, rp->offset, v);
		
		}
}

static void __init godson2e_piix_func1_fixup(struct pci_dev *pdev)
{
		unsigned long len;

	    if(PCI_SLOT(pdev->devfn) == P6032_PCIDEV_I82371) {
		
			/* enable mouse interrupt helper (converts edge triggered into level?) */
			unsigned short xbcs;
			(void) pci_read_config_word (pdev, I82371_XBCS, &xbcs);
			xbcs |= 0x0010;
			(void) pci_write_config_word (pdev, I82371_XBCS, xbcs);

#ifdef CONFIG_BLK_DEV_IDEPCI
		/*
		 * IDE Decode enable.
		 * somebody else will set up DMA timings if needed
		 */
#define IDETIM(s) I82371_PCI1IDETIM_##s
		(void) pci_write_config_word(pdev, I82371_PCI1IDETIM,
					     IDETIM(IDE) |
					     IDETIM(PPE1) | IDETIM(IE1) | IDETIM(TIME1) | 
					     IDETIM(PPE0) | IDETIM(IE0) | IDETIM(TIME0));
		(void) pci_write_config_word(pdev, I82371_PCI1IDETIM+2,
					     IDETIM(IDE) |
					     IDETIM(PPE1) | IDETIM(IE1) | IDETIM(TIME1) | 
					     IDETIM(PPE0) | IDETIM(IE0) | IDETIM(TIME0));
#endif /* CONFIG_BLK_DEV_IDEPCI */
	} //if

#ifdef CONFIG_BLK_DEV_IDEDMA
		/* set the BUS MASTER INTERFACE BASE */
		{
		
			const unsigned int default_bmiba = 0xcc0;  /* completely arbitrary */
			unsigned int bmiba;
			unsigned short pcicmd;

			(void) pci_read_config_word (pdev, PCI_COMMAND, &pcicmd);
			/* initialise BMIBA unless it has already been done */
			(void) pci_read_config_dword (pdev, PCI_BASE_ADDRESS_4, &bmiba);
			bmiba &= PCI_BASE_ADDRESS_IO_MASK;
			if (bmiba == 0) {
				bmiba = default_bmiba;
				/* The IO enable bit is meant to be set after setting BMIBA */
				if (pcicmd & PCI_COMMAND_IO) {
					pcicmd &= ~PCI_COMMAND_IO;
					pci_write_config_word (pdev, PCI_COMMAND, pcicmd);
				}
				(void) pci_write_config_dword (pdev, PCI_BASE_ADDRESS_4,
							       bmiba | PCI_BASE_ADDRESS_SPACE_IO);
			}
#define FIXUP_BONITO_BUG
#ifdef FIXUP_BONITO_BUG
			len = pdev->resource[4].end - pdev->resource[4].start;
			pdev->resource[4].end = bmiba + len;
#endif
			
			pdev->resource[4].start = bmiba;
			
			/* make sure IO accesses and bus mastering is enabled */
			pcicmd |= PCI_COMMAND_IO | PCI_COMMAND_MASTER;
			(void) pci_write_config_word (pdev, PCI_COMMAND, pcicmd);
			pci_read_config_dword(pdev, PCI_STATUS, &pcicmd);
			printk("FIXED ide ,STATUS =%x\n",pcicmd);
			if(pcicmd &0x2000)
				printk("wwww IDE master abort ???\n");
			pci_write_config_word(pdev, PCI_STATUS, pcicmd | 0x2000);
		}
#endif /* CONFIG_BLK_DEV_IDEDMA */
}



//#define Bonito static char * const _bonito = (char * const )KSEG1ADDR(BONITO_BASE)
static void __init godson2e_686b_func0_fixup(struct pci_dev *pdev)
{
	unsigned char c;

	printk("via686b fix: ISA bridge\n");

	/*  Enable I/O Recovery time */
	pci_write_config_byte(pdev, 0x40, 0x08);

	/*  Enable ISA refresh */
	pci_write_config_byte(pdev, 0x41, 0x01);

	/*  disable ISA line buffer */
	pci_write_config_byte(pdev, 0x45, 0x00);

	/*  Gate INTR, and flush line buffer */
	pci_write_config_byte(pdev, 0x46, 0xe0);

	/*  Disable PCI Delay Transaction, Enable EISA ports 4D0/4D1. */
	//pci_write_config_byte(pdev, 0x47, 0x20); 
	/*  enable PCI Delay Transaction, Enable EISA ports 4D0/4D1. 
	 *  enable time-out timer 
	 */
	pci_write_config_byte(pdev, 0x47, 0xe6); 

	/* enable level trigger on pci irqs: 9,10,11,13 */
	/* important! without this PCI interrupts won't work */
	outb(0x2e,0x4d1);

	/*  512 K PCI Decode */
	pci_write_config_byte(pdev, 0x48, 0x01);

	/*  Wait for PGNT before grant to ISA Master/DMA */
	pci_write_config_byte(pdev, 0x4a, 0x84);

	/*  Plug'n'Play */
	/*  Parallel DRQ 3, Floppy DRQ 2 (default) */
	pci_write_config_byte(pdev, 0x50, 0x0e);

	/*  IRQ Routing for Floppy and Parallel port */
	/*  IRQ 6 for floppy, IRQ 7 for parallel port */
	pci_write_config_byte(pdev, 0x51, 0x76);

	/*  IRQ Routing for serial ports (take IRQ 3 and 4) */
	pci_write_config_byte(pdev, 0x52, 0x34);

	/*  All IRQ's level triggered. */
	pci_write_config_byte(pdev, 0x54, 0x00);


	/* route PIRQA-D irq */
	pci_write_config_byte(pdev,0x55, 0x90); /* bit 7-4, PIRQA */
	pci_write_config_byte(pdev,0x56, 0xba); /* bit 7-4, PIRQC; 3-0, PIRQB */
	pci_write_config_byte(pdev,0x57, 0xd0); /* bit 7-4, PIRQD */

	/* enable function 5/6, audio/modem */
	pci_read_config_byte(pdev,0x85, &c); 
	c &= ~(0x3<<2);
	pci_write_config_byte(pdev,0x85,c);

	printk("via686b fix: ISA bridge done\n");
}


static void __init godson2e_686b_func1_fixup(struct pci_dev *pdev)
{
	printk("via686b fix: IDE\n");

	/* Modify IDE controller setup */
	pci_write_config_byte(pdev,PCI_LATENCY_TIMER, 48); //0xd0
	pci_write_config_byte(pdev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
	pci_write_config_byte(pdev, 0x40, 0x0b); 
	/* legacy mode */
	pci_write_config_byte(pdev, 0x42, 0x09);   
#if 0
	/* disable read prefetch/write post buffers */
	pci_write_config_byte(pdev, 0x41, 0x02); //0xf2);  

	/* use 3/4 as fifo thresh hold  */
	pci_write_config_byte(pdev, 0x43, 0x0a);//qqqw

	pci_write_config_byte(pdev, 0x44, 0x00);

	pci_write_config_byte(pdev, 0x45, 0x00);
#else
	pci_write_config_byte(pdev, 0x41, 0xc2); 
	pci_write_config_byte(pdev, 0x43, 0x35);
	pci_write_config_byte(pdev, 0x44, 0x1c);

	pci_write_config_byte(pdev, 0x45, 0x10);
#endif

	printk("via686b fix: IDE done\n");
}

static void __init godson2e_686b_func5_fixup(struct pci_dev *pdev)
{
	unsigned int val;
	unsigned char c;

	/* enable IO */
	pci_write_config_byte(pdev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
	pci_read_config_dword(pdev, 0x4, &val);
	pci_write_config_dword(pdev, 0x4, val | 1);

	/* route ac97 IRQ */
	pci_write_config_byte(pdev, 0x3c, 9);
	pdev->irq = 9;
	printk("ac97 interrupt = 9\n");

	pci_read_config_byte(pdev, 0x8, &c);
	printk("ac97 rev=%d\n",c);

	/* link control: enable link & SGD PCM output */
	pci_write_config_byte(pdev, 0x41, 0xcc);

	/* disable game port, FM, midi, sb, enable write to reg2c-2f */
	pci_write_config_byte(pdev, 0x42, 0x20);

	printk("Setting sub-vendor ID & device ID\n");

	/* we are using Avance logic codec */
	pci_write_config_word(pdev, 0x2c, 0x1005);
	pci_write_config_word(pdev, 0x2e, 0x4710);
	pci_read_config_dword(pdev, 0x2c, &val);
	printk("sub vendor-device id=%x\n",val);

	pci_write_config_byte(pdev, 0x42, 0x0);
}

static void __init godson2e_fixup_pcimap(void)
{
  	Bonito;
			
	unsigned long tmp;
	static	int inited=0;
	if(inited)return;
	inited=1;

	/* 
	 * 	 Make pci address mapping coincident with cpu address mapping
	 * 	  1. use (both cpu&pci) space [256M,448M] for pci dev mem
	 * 	  2. allocate pci io address from 0x10000,pci iomem from 0x10000000
	 * 	  3. use pci_auto to allocate pci resource to pci devices
	 * 	 The only benefit of doing so is to avoid broken of some drivers
	 * 	 really ugly and dangerous:(
	 */
	/* local to PCI mapping: [256M,512M] -> [256M,512M] */
	prom_printf("default pcimap=%08lx\n",BONITO_PCIMAP);
	/* 
	 * 	 cpu address space [256M,448M] is window for accessing pci space
	 * 	 we set pcimap_lo[0,1,2] to map it to pci space [256M,448M]
	 * 	  pcimap: bit18,pcimap_2; bit[17-12],lo2;bit[11-6],lo1;bit[5-0],lo0
	 */
	/* 1,00 0110 ,0001 01,00 0100 */
	/*
	 BONITO_PCIMAP = 0x46144;
	 prom_printf("pcimap set to %08lx\n",BONITO_PCIMAP);
	 */

	/* 1,00 0110 ,0001 01,00 0000 */
	BONITO_PCIMAP = 0x46140;
	//1, 00 0010, 0000,01, 00 0000
	//BONITO_PCIMAP = 0x42040;

	/* 
	 * PCI to local mapping: [2G,2G+256M] -> [0,256M]
	 */
#ifndef CONFIG_LOOKLIKE_PC
	BONITO_PCIBASE0 = 0x80000000; 
#else
	BONITO_PCIBASE0 = 0x00000000; 
#endif
	BONITO_PCIBASE1 = 0x00000000; 
	BONITO_PCIBASE2 = 0x70000000;    //assign a none used address.
	BONITO_PCI_REG(0x40)=0x80000000; //base0's mask register
#ifndef CONFIG_LOOKLIKE_PC
	BONITO_PCI_REG(0x44)=0xf0000000; //base1's mask register,for nobigmem and floppy
#else
	BONITO_PCI_REG(0x44)=0x80000000; //base1's mask register,for nobigmem and floppy
#endif
								
	/* if needed then enable io cache for mem 0*/
	if (BONITO_PCIMEMBASECFG & BONITO_PCIMEMBASECFG_MEMBASE0_CACHED) 
	  		BONITO_PCIMEMBASECFG = BONITO_PCIMEMBASECFG_MEMBASE0_CACHED;
	else
	  		BONITO_PCIMEMBASECFG = 0x0;

}

DECLARE_PCI_FIXUP_HEADER(PCI_ANY_ID, PCI_ANY_ID, godson2e_fixup_pcimap);
#if 0
DECLARE_PCI_FIXUP_HEADER(0x3388, 0x0021,godson2e_piix_func0_fixup);
DECLARE_PCI_FIXUP_EARLY(PCI_VENDOR_ID_INTEL, PCI_DEVICE_ID_INTEL_82371AB,
       godson2e_piix_func1_fixup);
#endif

DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C686,godson2e_686b_func0_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C586_1,godson2e_686b_func1_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C686_5,godson2e_686b_func5_fixup);
#endif
