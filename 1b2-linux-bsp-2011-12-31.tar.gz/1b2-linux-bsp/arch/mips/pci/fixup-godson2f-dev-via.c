/*
 * fixup-godson2e.c
 *
 * Copyright (C) 2004 ICT CAS
 * Author: Li xiaoyu, ICT CAS
 *   lixy@ict.ac.cn
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the  License, or (at your
 *  option) any later version.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
#include <linux/autoconf.h>
#include <linux/init.h>
#include <linux/pci.h>
#include <bonito.h>

#undef P6032_PCIDEV_SLOT1
#undef P6032_PCIDEV_SLOT2
#undef P6032_PCIDEV_SLOT3
#undef P6032_PCIDEV_SLOT4
#undef P6032_PCIDEV_ETH
#undef P6032_PCIDEV_I82371
#undef P6032_PCIDEV_BONITO
#undef P6032INT_IRQA
#undef P6032INT_IRQB
#undef P6032INT_IRQC
#undef P6032INT_IRQD

#define P6032_PCIDEV_SLOT1 13
#define P6032_PCIDEV_SLOT2 14
#define P6032_PCIDEV_SLOT3 15
#define P6032_PCIDEV_SLOT4 18
#define P6032_PCIDEV_ETH 16
#define P6032_PCIDEV_I82371 17
#define P6032_PCIDEV_BONITO 19


#define P6032INT_IRQA 36
#define P6032INT_IRQB 37
#define P6032INT_IRQC 38
#define P6032INT_IRQD 39

int __init pcibios_map_irq(struct pci_dev *dev, u8 slot, u8 pin)
{
  if(dev->devfn == (17<<3 | 2)){
#define USB1_IRQ 11
			pci_write_config_byte(dev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
			pci_write_config_byte(dev, 0x3c, USB1_IRQ);
			dev->irq=USB1_IRQ;
		return dev->irq;
  }
  else if(dev->devfn == (17<<3 | 3)){
#define USB2_IRQ 10
			pci_write_config_byte(dev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
			pci_write_config_byte(dev, 0x3c, USB2_IRQ);
			dev->irq = USB2_IRQ;
			return dev->irq;
  }
  else if(dev->devfn == (17<<3 | 5)){

			/* route ac97 IRQ */
			pci_write_config_byte(dev, 0x3c, 9);
			dev->irq = 9;
		return dev->irq;
  }
 else if (slot == 16) { /* 8139 */ 
			dev->irq = P6032INT_IRQA;
			(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
			return dev->irq;
 }else if (slot >=12 && slot <=15) { /* usb */
			dev->irq = P6032INT_IRQA +(((slot-12)+ (pin-1))&3);
			(void) pci_write_config_byte(dev, PCI_INTERRUPT_LINE, dev->irq);
			return dev->irq;
}
  else return 0;
}


/* Do platform specific device initialization at pci_enable_device() time */
int pcibios_plat_dev_init(struct pci_dev *dev)
{
	return 0;
}


//#define Bonito static char * const _bonito = (char * const )KSEG1ADDR(BONITO_BASE)
static void __init godson2e_686b_func0_fixup(struct pci_dev *pdev)
{
	unsigned char c;

	printk("via686b fix: ISA bridge\n");

	/*  Enable I/O Recovery time */
	pci_write_config_byte(pdev, 0x40, 0x08);

	/*  Enable ISA refresh */
	pci_write_config_byte(pdev, 0x41, 0x01);

	/*  disable ISA line buffer */
	pci_write_config_byte(pdev, 0x45, 0x00);

	/*  Gate INTR, and flush line buffer */
	pci_write_config_byte(pdev, 0x46, 0xe0);

	/*  Disable PCI Delay Transaction, Enable EISA ports 4D0/4D1. */
	//pci_write_config_byte(pdev, 0x47, 0x20); 
	/*  enable PCI Delay Transaction, Enable EISA ports 4D0/4D1. 
	 *  enable time-out timer 
	 */
	pci_write_config_byte(pdev, 0x47, 0xe6); 

	/* enable level trigger on pci irqs: 9,10,11,13 */
	/* important! without this PCI interrupts won't work */
	outb(0x2e,0x4d1);

	/*  512 K PCI Decode */
	pci_write_config_byte(pdev, 0x48, 0x01);

	/*  Wait for PGNT before grant to ISA Master/DMA */
	pci_write_config_byte(pdev, 0x4a, 0x84);

	/*  Plug'n'Play */
	/*  Parallel DRQ 3, Floppy DRQ 2 (default) */
	pci_write_config_byte(pdev, 0x50, 0x0e);

	/*  IRQ Routing for Floppy and Parallel port */
	/*  IRQ 6 for floppy, IRQ 7 for parallel port */
	pci_write_config_byte(pdev, 0x51, 0x76);

	/*  IRQ Routing for serial ports (take IRQ 3 and 4) */
	pci_write_config_byte(pdev, 0x52, 0x34);

	/*  All IRQ's level triggered. */
	pci_write_config_byte(pdev, 0x54, 0x00);


	/* route PIRQA-D irq */
	pci_write_config_byte(pdev,0x55, 0x90); /* bit 7-4, PIRQA */
	pci_write_config_byte(pdev,0x56, 0xba); /* bit 7-4, PIRQC; 3-0, PIRQB */
	pci_write_config_byte(pdev,0x57, 0xd0); /* bit 7-4, PIRQD */

	/* enable function 5/6, audio/modem */
	pci_read_config_byte(pdev,0x85, &c); 
	c &= ~(0x3<<2);
	pci_write_config_byte(pdev,0x85,c);

	printk("via686b fix: ISA bridge done\n");
}


static void __init godson2e_686b_func1_fixup(struct pci_dev *pdev)
{
	printk("via686b fix: IDE\n");

	/* Modify IDE controller setup */
	pci_write_config_byte(pdev,PCI_LATENCY_TIMER, 48); //0xd0
	pci_write_config_byte(pdev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
	pci_write_config_byte(pdev, 0x40, 0x0b); 
	/* legacy mode */
	pci_write_config_byte(pdev, 0x42, 0x09);   
#if 0
	/* disable read prefetch/write post buffers */
	pci_write_config_byte(pdev, 0x41, 0x02); //0xf2);  

	/* use 3/4 as fifo thresh hold  */
	pci_write_config_byte(pdev, 0x43, 0x0a);//qqqw

	pci_write_config_byte(pdev, 0x44, 0x00);

	pci_write_config_byte(pdev, 0x45, 0x00);
#else
	pci_write_config_byte(pdev, 0x41, 0xc2); 
	pci_write_config_byte(pdev, 0x43, 0x35);
	pci_write_config_byte(pdev, 0x44, 0x9c);

	pci_write_config_byte(pdev, 0x45, 0x10);
#endif

	printk("via686b fix: IDE done\n");
}

static void __init godson2e_686b_func5_fixup(struct pci_dev *pdev)
{
	unsigned int val;
	unsigned char c;

	/* enable IO */
	pci_write_config_byte(pdev, PCI_COMMAND, PCI_COMMAND_IO|PCI_COMMAND_MEMORY|PCI_COMMAND_MASTER);
	pci_read_config_dword(pdev, 0x4, &val);
	pci_write_config_dword(pdev, 0x4, val | 1);

	/* route ac97 IRQ */
	pci_write_config_byte(pdev, 0x3c, 9);
	pdev->irq = 9;
	printk("ac97 interrupt = 9\n");

	pci_read_config_byte(pdev, 0x8, &c);
	printk("ac97 rev=%d\n",c);

	/* link control: enable link & SGD PCM output */
	pci_write_config_byte(pdev, 0x41, 0xcc);

	/* disable game port, FM, midi, sb, enable write to reg2c-2f */
	pci_write_config_byte(pdev, 0x42, 0x20);

	printk("Setting sub-vendor ID & device ID\n");

	/* we are using Avance logic codec */
	pci_write_config_word(pdev, 0x2c, 0x1005);
	pci_write_config_word(pdev, 0x2e, 0x4710);
	pci_read_config_dword(pdev, 0x2c, &val);
	printk("sub vendor-device id=%x\n",val);

	pci_write_config_byte(pdev, 0x42, 0x0);
}

//#define Bonito static char * const _bonito = (char * const )CKSEG1ADDR(BONITO_BASE)
static void __init godson2f_fixup_pcimap(struct pci_dev *pdev)
{
  	Bonito;
	static int first = 1;

	(void)pdev;
	if (first) first = 0; else return;
			
	/* 
	 * 	 Make pci address mapping coincident with cpu address mapping
	 * 	  1. use (both cpu&pci) space [256M,448M] for pci dev mem
	 * 	  2. allocate pci io address from 0x10000,pci iomem from 0x10000000
	 * 	  3. use pci_auto to allocate pci resource to pci devices
	 * 	 The only benefit of doing so is to avoid broken of some drivers
	 * 	 really ugly and dangerous:(
	 */
	/* local to PCI mapping: [256M,512M] -> [256M,512M] */
	/* 
	 * 	 cpu address space [256M,448M] is window for accessing pci space
	 * 	 we set pcimap_lo[0,1,2] to map it to pci space [256M,448M]
	 * 	  pcimap: bit18,pcimap_2; bit[17-12],lo2;bit[11-6],lo1;bit[5-0],lo0
	 */
	/* 1,00 0110 ,0001 01,00 0000 */
	BONITO_PCIMAP = 0x46140;
	//1, 00 0010, 0000,01, 00 0000
	//BONITO_PCIMAP = 0x42040;

	/* 
	 * PCI to local mapping: [2G,2G+256M] -> [0,256M]
	 */
	BONITO_PCIBASE0 = 0x80000000; 
	BONITO_PCIBASE1 = 0x0;
	BONITO(BONITO_REGBASE + 0x50) = 0x8000000c;
	BONITO(BONITO_REGBASE + 0x54) = 0xffffffff;

	/*set pci 2G -> DDR 0 ,window size 2G*/
	  asm(".set mips3;dli $2,0x900000003ff00000;li $3,0x80000000;sd $3,0x60($2);sd $0,0xa0($2);dli $3,0xffffffff80000000;sd $3,0x80($2);.set mips0" :::"$2","$3");

	/* 
	 * PCI to local mapping: [8M,16M] -> [8M,16M]
	 */
	BONITO_PCI_REG(0x18) = 0x00800000; 
	BONITO_PCI_REG(0x1c) = 0x0;
	BONITO(BONITO_REGBASE + 0x58) = 0xff80000c;
	BONITO(BONITO_REGBASE + 0x5c) = 0xffffffff;

	/*set pci 8-16M -> DDR 8-16M ,window size 8M*/
	  asm(".set mips3;dli $2,0x900000003ff00000;li $3,0x800000;sd $3,0x68($2);sd $3,0xa8($2);dli $3,0xffffffffff800000;sd $3,0x88($2);.set mips0" :::"$2","$3");
								
	/* if needed then enable io cache for mem 0*/
	if (BONITO_PCIMEMBASECFG & BONITO_PCIMEMBASECFG_MEMBASE0_CACHED) 
	  		BONITO_PCIMEMBASECFG = BONITO_PCIMEMBASECFG_MEMBASE0_CACHED;
	else
	  		BONITO_PCIMEMBASECFG = 0x0;
}

DECLARE_PCI_FIXUP_HEADER(PCI_ANY_ID, PCI_ANY_ID, godson2f_fixup_pcimap);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C686,godson2e_686b_func0_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C586_1,godson2e_686b_func1_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_VIA, PCI_DEVICE_ID_VIA_82C686_5,godson2e_686b_func5_fixup);

