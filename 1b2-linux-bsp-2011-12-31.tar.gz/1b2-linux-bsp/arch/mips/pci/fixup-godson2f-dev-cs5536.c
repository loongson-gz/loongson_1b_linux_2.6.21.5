/*
 * fixup-lm2e.c
 *
 * Copyright (C) 2004 ICT CAS
 * Author: Li xiaoyu, ICT CAS
 *   lixy@ict.ac.cn
 *
 * Copyright (C) 2007 Lemote, Inc. & Institute of Computing Technology
 * Author: Fuxin Zhang, zhangfx@lemote.com
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the  License, or (at your
 *  option) any later version.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
#include <linux/init.h>
#include <linux/pci.h>
#include <bonito.h>

/* PCI interrupt pins */
/* These should not be changed, or you should consider godson2f interrupt register and
 * your pci card dispatch
 */
#define PCIA		4
#define PCIB		5
#define PCIC		6
#define PCID		7

#undef P6032INT_IRQA
#undef P6032INT_IRQB
#undef P6032INT_IRQC
#undef P6032INT_IRQD
#define P6032INT_IRQA (BONITO_IRQ_BASE+4)
#define P6032INT_IRQB (BONITO_IRQ_BASE+5)
#define P6032INT_IRQC (BONITO_IRQ_BASE+6)
#define P6032INT_IRQD (BONITO_IRQ_BASE+7)

int __init pcibios_map_irq(struct pci_dev *dev, u8 slot, u8 pin)
{

	if(slot>=11 && slot<=13)
	{
	 dev->irq=(pin-1)+P6032INT_IRQA+(slot-11);
	 return dev->irq;
	}
	else if( slot == 14){	// cs5536
		switch(PCI_FUNC(dev->devfn)){
			case 2 :
				dev->irq = 14;	// for IDE
				break;
			case 3 :
				dev->irq = 9;	// for AUDIO
				break;
			case 4 :		// for OHCI
			case 5 :		// for EHCI
			case 6 :		// for UDC
			case 7 :		// for OTG
				dev->irq = 11;	
				break;			
		}
		return dev->irq;
	}else{
		printk(" strange pci slot number.\n");
		return 0;
	}
}

/* Do platform specific device initialization at pci_enable_device() time */
int pcibios_plat_dev_init(struct pci_dev *dev)
{
	return 0;
}

#ifndef	TEST_NO_CS5536
/* CS5536 SPEC. fixup */
static void __init loongson2e_cs5536_isa_fixup(struct pci_dev *pdev)
{
	/* the uart1 and uart2 interrupt in PIC is enabled as default */
	pci_write_config_dword(pdev, 0x50, 1);
	pci_write_config_dword(pdev, 0x54, 1);
	/* enable the pci MASTER ABORT/ TARGET ABORT etc. */
	pci_write_config_dword(pdev, 0x58, 1);
	return;
}


static void __init loongson2e_cs5536_ide_fixup(struct pci_dev *pdev)
{
	/* setting the mutex pin as IDE function */
	/* the IDE interrupt in PIC is enabled as default */
	pci_write_config_dword(pdev, 0x40, 0xDEADBEEF);
	return;
}

static void __init loongson2e_cs5536_acc_fixup(struct pci_dev *pdev)
{
	/* enable the AUDIO interrupt in PIC  */
	pci_write_config_dword(pdev, 0x50, 1);
	return;
}

static void __init loongson2e_cs5536_ohci_fixup(struct pci_dev *pdev)
{
	/* enable the OHCI interrupt in PIC */
	/* THE OHCI, EHCI, UDC, OTG are shared with interrupt in PIC */
	pci_write_config_dword(pdev, 0x50, 1);
	return;
}

static void __init loongson2e_cs5536_ehci_fixup(struct pci_dev *pdev)
{
	/* setting the USB2.0 micro frame length */
	pci_write_config_dword(pdev, 0x60, 0x2000);
	return;
}
#endif	/* TEST_NO_CS5536 */

static void __init loongson2e_fixup_pcimap(struct pci_dev *pdev)
{
  	Bonito;
	static int first = 1;

	(void)pdev;
	if (first)
		first = 0;
	else
		return;

	/* 1,00 0110 ,0001 01,00 0000 */
	BONITO_PCIMAP = 0x46140;
	//1, 00 0010, 0000,01, 00 0000
	//BONITO_PCIMAP = 0x42040;

	/* 
	 * PCI to local mapping: [2G,2G+256M] -> [0,256M]
	 */
	BONITO_PCIBASE0 = 0x80000000; 
	BONITO_PCIBASE1 = 0x0;
	BONITO(BONITO_REGBASE + 0x50) = 0x8000000c;
	BONITO(BONITO_REGBASE + 0x54) = 0xffffffff;

	/*set pci 2G -> DDR 0 ,window size 2G*/
	  asm(".set mips3;dli $2,0x900000003ff00000;li $3,0x80000000;sd $3,0x60($2);sd $0,0xa0($2);dli $3,0xffffffff80000000;sd $3,0x80($2);.set mips0" :::"$2","$3");

	/* 
	 * PCI to local mapping: [8M,16M] -> [8M,16M]
	 */
	BONITO_PCI_REG(0x18) = 0x00800000; 
	BONITO_PCI_REG(0x1c) = 0x0;
	BONITO(BONITO_REGBASE + 0x58) = 0xff80000c;
	BONITO(BONITO_REGBASE + 0x5c) = 0xffffffff;

	/*set pci 8-16M -> DDR 8-16M ,window size 8M*/
	  asm(".set mips3;dli $2,0x900000003ff00000;li $3,0x800000;sd $3,0x68($2);sd $3,0xa8($2);dli $3,0xffffffffff800000;sd $3,0x88($2);.set mips0" :::"$2","$3");
								
	/* if needed then enable io cache for mem 0*/
	if (BONITO_PCIMEMBASECFG & BONITO_PCIMEMBASECFG_MEMBASE0_CACHED) 
	  		BONITO_PCIMEMBASECFG = BONITO_PCIMEMBASECFG_MEMBASE0_CACHED;
	else
	  		BONITO_PCIMEMBASECFG = 0x0;
}

#ifndef	TEST_NO_CS5536
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_AMD, PCI_DEVICE_ID_AMD_CS5536_ISA, 
			 loongson2e_cs5536_isa_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_AMD, PCI_DEVICE_ID_AMD_CS5536_OHC, 
			 loongson2e_cs5536_ohci_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_AMD, PCI_DEVICE_ID_AMD_CS5536_EHC, 
			 loongson2e_cs5536_ehci_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_AMD, PCI_DEVICE_ID_AMD_CS5536_AUDIO, 
			 loongson2e_cs5536_acc_fixup);
DECLARE_PCI_FIXUP_HEADER(PCI_VENDOR_ID_AMD, PCI_DEVICE_ID_AMD_CS5536_IDE, 
			 loongson2e_cs5536_ide_fixup);
#endif	/* TEST_NO_CS5536 */
DECLARE_PCI_FIXUP_HEADER(PCI_ANY_ID, PCI_ANY_ID, loongson2e_fixup_pcimap);
